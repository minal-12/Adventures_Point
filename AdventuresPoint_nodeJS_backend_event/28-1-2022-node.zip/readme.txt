npm init -y

npm i express body-parser mongoose mysql ejs dotenv